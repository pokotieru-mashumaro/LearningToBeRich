/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ps_error.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: komatsukotarou <komatsukotarou@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/19 15:47:51 by kkomatsu          #+#    #+#             */
/*   Updated: 2024/05/05 02:19:49 by komatsukota      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

static int	is_int(char *s)
{
	int	i;
	int	max;
	int zero_count;

	i = 0;
	zero_count = 0;
	max = ft_strlen(s);
	if (max == 1 && (s[i] < '0' || '9' < s[i]))
		return (0);
	while (s[zero_count] == '0')
		zero_count++;
	
	while (i < max)
	{
		if ((s[0] != '-'))
			if (s[i] < '0' || '9' < s[i])
				return (0);
		if (s[0] == '-' && s[1] == '0')
			return (0);
		i++;
	}
	if (ft_atol(s) < INT_MIN || INT_MAX < ft_atol(s))
		return (0);
	if (zero_count > 1)
		return 0;
	return (1);
}

int	is_av_error(int ac, char **av)
{
	int		i;
	int		j;
	char	**stock;
	int		av_count;

	i = 0;
	av_count = 0;
	while (av[av_count])
		av_count++;
	stock = (char **)malloc(sizeof(char *) * av_count);
	if (!stock)
		return (1);
	while (i < av_count)
	{
		stock[i] = NULL;
		if (!is_int(av[i]))
			return (1);
		j = 0;
		while (stock[j])
		{
			if (ft_strcmp(av[i], stock[j]) == 0)
				return (1);
			j++;
		}
		stock[i] = av[i];
		i++;
	}
	stock[i] = NULL;
	return (0);
}

int	output_error(void)
{
	write(1, "Error\n", 6);
	return (0);
}
