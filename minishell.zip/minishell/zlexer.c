#include "minishell.h"


// 後ろが<, >, <<, >>, |、それ以外かチェックし、それぞれの処理に移行
//0:それ以外 次に移行
//1:<, >, <<, >>,エラー syntax error near unexpected token `newline'
//2: < |, > |, | |,エラー syntax error near unexpected token `|'
//3: syntax error near unexpected token `;'
//4:| 待ち受け
//よくわからんところ <| a| など |にくっつく時
//よくわからんところ <>
// int check_per_pipe_line_ass(char **line)
// {
//     int i;
//     int final_is_pipe;
//     char **until_pipe_stk;
//     char **start_ptr;

//     i = 0;
//     if (!ft_strcmp(*line, "|"))
//         return 2;
//     if (!ft_strcmp(*line, ";"))
//         return 3;

//      //ここの条件がおかしい！！！
//     while (*line && (ft_strcmp(*line, "|") || ft_strcmp(*line, ";")))
//     {
//         final_is_pipe = 0;
//         start_ptr = line;

//         //ここの条件がおかしい！！！
//         while (*line && (ft_strcmp(*line, "|") || ft_strcmp(*line, ";")))
//             line++;


//         //現時点でのlineは "|" or ";" or null
//         printf("------%s\n", *line);
//         until_pipe_stk = put_until_pipe(line, start_ptr);
//         if (judgment_return_one_or_two(until_pipe_stk) && !*line)
//             return 1;
//         else if (judgment_return_one_or_two(until_pipe_stk) && !ft_strcmp(*line, "|"))
//             return 2;
//         else if (judgment_return_one_or_two(until_pipe_stk) && !ft_strcmp(*line, ";"))
//             return 3;

//          //ここの条件がおかしい！！！
//         if (*line && (!ft_strcmp(*line, "|") || !ft_strcmp(*line, ";")))
//         {
            
//             if (!ft_strcmp(*line, "|"))
//                 final_is_pipe = 1;
//             line++;
//             if (!ft_strcmp(*line, "|"))
//                 return 2;
//             if (!ft_strcmp(*line, ";"))
//                 return 3;
//         }
//     }
//     if (final_is_pipe)
//         return 4;
//     return 0;
// }



int count_for_rearrange_line(char **line)
{
    int count;

    count = 0;
    while (*line)
    {
        if (!ft_strcmp(*line, "|"))
            count += 1;
        if (!ft_strcmp(*line, ";"))
            count += 2;
        count++;
        line++;
    }
    count += 3;
    return 0;
}

/*
< infile cmd option > outfile |
で並び替える。
ロジック：消去法 - <, >を先に移動し、その後cmd option
*/
char **rearrange_line(char **line)
{
    char **ret;

    ret = (char **)malloc(count_for_rearrange_line(line) * sizeof(char *));
    while (*line)
    {
        line++;
    }
    return ret;   
}





int quotes_is_odd(char *s)
{
    int single_quotes;
    int double_quotes;

    single_quotes = 0;
    double_quotes = 0;
    while (*s)
    {
        if (*s == '\'')
            single_quotes++;
        else if (*s == '\"')
            double_quotes++; 
        s++;
    }
    if (single_quotes % 2 == 1)
        return 1;
    else if (double_quotes % 2 == 1)
        return 1;
    else 
        return 0;
}

int cut_or_read(char **line)
{
    char *stk;

    while (*line)
    {
        if (!quotes_is_odd(*line))
        {
            stk = ft_strtrim(*line, "\"\'");
            free(*line);
            *line = stk;
        }
        else
            return 1;
        line++;
    }
    return 0;
}


int output_error(char *item)
{
    ft_putstr_fd("syntax error near unexpected token `", 1);
    if (item)
        ft_putstr_fd(item, 1);
    else
        ft_putstr_fd("newline", 1);
    ft_putstr_fd("'\n", 1);
    return 1;
}

int select_output(char *item, char *next)
{
    if (!ft_strcmp(item, "|") | !ft_strcmp(item, ";"))
    {
        if (!next)
            return output_error(item);
        else if (!ft_strcmp(next, "|") | !ft_strcmp(next, ";"))
            return output_error(next);
    }
    if (!ft_strcmp(item, "<") | !ft_strcmp(item, ">") | !ft_strcmp(item, "<<") | !ft_strcmp(item, ">>"))
    {
        if (!next)
            return output_error(next);
        else
           return output_error(next); 
    }
    return 0;
}

//左から一つずつ見ていく。
//一つ右を確認
//itemだったらsyntax error
int find_syntax_error(char **line)
{
    int i;

    i = 0;
    while (line[i])
    {
        if (select_output(line[i], line[i + 1]))
            return 1;
        i++;
    }
    return 0;
}

//1.split: ft_split_for_lexer関数
//2.クオートが奇数だったら受付、偶数だったら次に進む: 
//3.クオートを消す
//4.文法エラーチェック
/*
文法エラーについて、
1. |, ;まで進める
2.進めた一つ左と進めたところを見て条件分岐
進めた一つ左が<,<<,>,>>,|,;の時
進めたところが | だった時、syntax error near unexpected token `|'
進めたところが ; だった時、syntax error near unexpected token `;'
進めたところが null だった時、syntax error near unexpected token `newline'

syntax error: unexpected end of file
*/
//5.
char **lexer(char *before_line)
{
    char **line;
    int error_check;

    line = ft_split_for_lexer(before_line);
    if (cut_or_read(line))
        printf("直ちに読み込みなさい\n");
    if (find_syntax_error(line))
        return NULL;
    // error_check = check_per_pipe_line_ass(first);
    // if (error_check == 0)
    //     rearrange_line(line);
    return line;
}

int main(int ac, char **av)
{
    char **ret = lexer(av[1]);
    // if (ret)
    // {
    //     for (int i = 0; ret[i] != NULL; i++)
    //     {
    //         printf("ret[%d]: %s\n", i, ret[i]);
    //     }
    // }
    return 0;
}